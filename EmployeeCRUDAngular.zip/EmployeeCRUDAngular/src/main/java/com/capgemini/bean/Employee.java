package com.capgemini.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Angular")
public class Employee {
	@Id
	@GeneratedValue
	private int eid;
	private int esal;
	private String ename;
	private String ecomp;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int esal) {
		this.esal = esal;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEcomp() {
		return ecomp;
	}
	public void setEcomp(String ecomp) {
		this.ecomp = ecomp;
	}
}
